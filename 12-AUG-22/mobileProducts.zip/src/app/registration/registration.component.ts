import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registerForm!:FormGroup;

  constructor(private fb:FormBuilder) { }
submitted!:boolean;

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      surName:['',[Validators.required]]
    })
  }

  validForm(){
   this.submitted = true;
   if(this.registerForm.invalid){
    return
   }else{
    console.log('Form Submitted Successfully');
    console.log(this.registerForm.value);
   }
  }

  get rf(){return this.registerForm.controls}
 // rf -> registerForm
}
